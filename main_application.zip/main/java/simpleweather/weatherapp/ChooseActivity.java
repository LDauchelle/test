package simpleweather.weatherapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;


public class ChooseActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose);
        Toast.makeText(getApplicationContext(), "If you put wrong lat/long, you can got nothing, it's normal", Toast.LENGTH_LONG).show();

    }

    public void OnSend(View view) throws Exception {

        EditText location_tf = (EditText)findViewById(R.id.editTextCity);
        String location = location_tf.getText().toString().toUpperCase();
        EditText location_lat = (EditText)findViewById(R.id.editTextLatitude);
        String Lat = location_lat.getText().toString();
        EditText location_lng = (EditText)findViewById(R.id.editTextLongitude);
        String Lng = location_lng.getText().toString();

        if (Lat.equals("") || Lng.equals(""))
        {
            Toast.makeText(getApplicationContext(), "Some field are empty", Toast.LENGTH_LONG).show();
        }
        else
        {
            try
            {
                SetData.setData(location,Lat,Lng);
                Intent intent = new Intent(ChooseActivity.this, MainActivity.class);
                startActivity(intent);

            } catch (Exception e) {
                Intent intent = new Intent(ChooseActivity.this, ChooseActivity.class);
                startActivity(intent);
        }
        }
    }

    public void OnMain(View view) {

        Intent intent = new Intent(ChooseActivity.this, MainActivity.class);
        startActivity(intent);

    }
}
