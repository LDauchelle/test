package simpleweather.weatherapp;

import android.app.Application;

public class DatStorage extends Application {

    private static String data="";
    private static String[] column=null;
    private static String[] row=null;
    private static String[] names=null;
    private static String[] temperatures=null;
    private static String[] icons=null;
    private static String[] lat=null;
    private static String[] lng=null;

    private static final String FILENAME = "cities.txt";


    public static String[] getNames() {
        return names;
    }
    public static String[] getTemperatures() {
        return temperatures;
    }
    public static String[] getIcons() {
        return icons;
    }
    public static String[] getLat() {
        return lat;
    }
    public static String[] getLng() {
        return lng;
    }


    public static void setData(String data_old) {
        data = data_old;
    }

    public static void DispatchData(){


        if (data !=null) {

            column = data.split(",");
            int length = column.length;
            int length2=0;
            for(int i = 0; i < length; i++){

                row = column[i].split(" ");
                names = column[i].split(" ");
                temperatures = column[i].split(" ");
                icons = column[i].split(" ");
                lat = column[i].split(" ");
                lng = column[i].split(" ");
                i++;

            }
            length2 = row.length;
            for(int x=0; x< length2;x++){
                names[x] = "";
                temperatures[x]="";
                icons[x]="";
                lat[x]="";
                lng[x]="";

            }
                int i =0;
                for (int j = 0; j < length; j++) {

                    names[j] = row[0+i];
                    temperatures[j] = row[1+i];
                    icons[j] = row[2+i];
                    lat[j] = row[3+i];
                    lng[j] = row[4+i];
                    i=i+5;
                }

        }
    }
}
