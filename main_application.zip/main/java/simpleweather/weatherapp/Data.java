package simpleweather.weatherapp;

public class Data {
    private String FILENAME="cities.txt";


    static String[] nameArray = {"Item0", "Item1", "Item2", "Item3", "Item4", "Item5","Item6", "item7", "Item8", "item9"};
    static Integer[] contactArray = {0,1 ,2 ,3 ,4 ,5 ,6 ,7 ,8 ,9 };



}
