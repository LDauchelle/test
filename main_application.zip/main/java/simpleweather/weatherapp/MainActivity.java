package simpleweather.weatherapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.text.Html;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    TextView cityField, detailsField, currentTemperatureField, humidity_field, pressure_field, weatherIcon, updatedField;

    Typeface weatherFont;
    Spinner spinner;
    ArrayAdapter<CharSequence> adapter;
    int check = 0;
    String Lat = "0";
    String Long = "0";
    int taille_content_recycler = 0;
    String content_name_recycler [];
    String content_lat_recyler [];
    String content_lng_recyler[];

    private static final String FILENAME = "cities.txt";
    private static String data_new = "";
    private static String data_old = "";
    String current_icon = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);

        //Affichage liste déroulante

        spinner = (Spinner) findViewById(R.id.spinner);
        adapter = ArrayAdapter.createFromResource(this, R.array.mode, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int i, long l) {
                check = check + 1;

                // Le spinner est le choix de l'utilisateur, entre choir une météo de ville sur google maps ou manuellement, ou alors consulter ses villes favorites

                if (check > 1) {
                    switch (i) {
                        case 0:
                            // Acceuil par défault
                            Intent intent = new Intent(MainActivity.this, MainActivity.class);
                            startActivity(intent);
                            break;
                        case 1:
                            // Google maps activité
                            Intent intent2 = new Intent(MainActivity.this, MapsActivity.class);
                            startActivity(intent2);
                            break;
                        case 2:
                            // Lat / Long activité
                            Intent intent3 = new Intent(MainActivity.this, ChooseActivity.class);
                            startActivity(intent3);
                            break;
                        case 3:
                            // Historique list
                            Intent intent4 = new Intent(MainActivity.this, SaveActivity.class);
                            startActivity(intent4);
                            break;
                        default:
                            // Case par default
                            Toast.makeText(MainActivity.this, "Error, page not found", Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        // Recherche des logos dans le dossier Assets ( images comme nuage ou soleil pour l'application )
        weatherFont = Typeface.createFromAsset(getAssets(), "fonts/weathericons-regular-webfont.ttf");

        cityField = (TextView) findViewById(R.id.city_field);
        updatedField = (TextView) findViewById(R.id.updated_field);
        detailsField = (TextView) findViewById(R.id.details_field);
        currentTemperatureField = (TextView) findViewById(R.id.current_temperature_field);
        humidity_field = (TextView) findViewById(R.id.humidity_field);
        pressure_field = (TextView) findViewById(R.id.pressure_field);
        weatherIcon = (TextView) findViewById(R.id.weather_icon);
        weatherIcon.setTypeface(weatherFont);


        // Recherche des informations pour chaque élèments de l'activitée dans le fichier Function.java ( si il fait beau, gris, pluvieux... )
        Function.placeIdTask asyncTask = new Function.placeIdTask(new Function.AsyncResponse() {
            public void processFinish(String weather_city, String weather_description, String weather_temperature, String weather_humidity, String weather_pressure, String weather_updatedOn, String weather_iconText, String sun_rise) {

                cityField.setText(weather_city);
                updatedField.setText(weather_updatedOn);
                detailsField.setText(weather_description);
                currentTemperatureField.setText(weather_temperature);
                humidity_field.setText("Humidity: " + weather_humidity);
                pressure_field.setText("Pression: " + weather_pressure);
                weatherIcon.setText(Html.fromHtml(weather_iconText));
                current_icon = weather_iconText;

            }
        });


        // Résulat final page d'acceuil, il lui faut pour fonctionner une lattitude ou une longitude( URL - api open-weather ne fonctionne qu'avec ses deux parametres )
        Lat = SetData.getLat();
        Long = SetData.getLng();

        asyncTask.execute(Lat, Long);
    }

    public void OnStore(View view) {

    SetData.convert_tab();
    Toast.makeText(getApplicationContext(), "Added!... Normally but this function not works for now", Toast.LENGTH_LONG).show();

    }
}
