package simpleweather.weatherapp;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Geocoder;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import java.util.List;


public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        // Google maps fragment prêt à l'emploi pour la gestion des divers outils
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {

        mMap = googleMap;

        // Add un markeur sur Angers en dûr pour commencer
        LatLng Angers = new LatLng(47.4666700, -0.5500000);
        mMap.addMarker(new MarkerOptions().position(Angers).title("Marker in angers"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(Angers));
    }

    private void SetUpMap() {
        mMap.addMarker(new MarkerOptions().position(new LatLng(0, 0)).title("Marker"));
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            mMap.setMyLocationEnabled(true);
           return;
        }
        else{
        Toast.makeText(getApplicationContext(), "Permission non accordée, please activate location", Toast.LENGTH_LONG).show();
    }
}
    // bouton recherche de l'utilisateur
    public void OnSearch(View view) throws Exception{

            EditText location_tf = (EditText) findViewById(R.id.TFaddress);
            String location = location_tf.getText().toString().toUpperCase();
            double lat = 0;
            double lng = 0;
            String Lat, Lng;

            List<android.location.Address> addressList = null;


                try {
                    Geocoder geocoder = new Geocoder(this);
                    addressList = geocoder.getFromLocationName(location, 1);
                    android.location.Address address = addressList.get(0);
                    LatLng latlng = new LatLng(address.getLatitude(), address.getLongitude());
                    mMap.clear();
                    mMap.addMarker(new MarkerOptions().position(latlng).title("Marker"));
                    mMap.animateCamera(CameraUpdateFactory.newLatLng(latlng));

                    lat = address.getLatitude();
                    Lat = String.valueOf(lat);
                    lng = address.getLongitude();
                    Lng = String.valueOf(lng);
                    SetData.setData(location, Lat, Lng);
                    Thread.sleep(2000); // pause pour voir votre ville choisie


                    Intent intent = new Intent(MapsActivity.this, MainActivity.class);
                    startActivity(intent);

                } catch (Exception e) {
                    e.printStackTrace();
                    if (!SetData.isOnline())
                        Toast.makeText(getApplicationContext(), "Your internet connection is limited, retry since you got a good one", Toast.LENGTH_LONG).show();
                    Toast.makeText(getApplicationContext(), "City name must be not good, put a good one please", Toast.LENGTH_LONG).show();
                }
    }

}
