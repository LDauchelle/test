package simpleweather.weatherapp;


import android.app.Application;

    // Cette classe regroupe les données transitant les différentes activitées afin de toujours garder une trace ainsi que divers test
    public class SetData extends Application {

        private static String location="Angers";

        private static String Actual_lat="47.4666700";
        private static String Actual_lng="-0.5500000";

        private static String[] tab_name;
        private static String[] tab_lat;
        private static String[] tab_lng;

        private static int taille_content_recycler=0;


        public static String getString() {
            return location;
        }
        public static String getLat(){
            return Actual_lat;
        }
        public static String getLng(){
            return Actual_lng;
        }

        private static String[] getTab_String() {return tab_name;}
        private static String[] getTab_lat() {return tab_lat;}
        private static String[] getTab_lng() {return tab_lng;}


        public static void setData(String someVariable, String Lat, String Lng) {

            location = someVariable;
            Actual_lat = Lat;
            Actual_lng = Lng;
        }

    public static Boolean isOnline() {
        try {
            Process p1 = java.lang.Runtime.getRuntime().exec("ping -c 1 www.google.com");
            int returnVal = p1.waitFor();
            boolean reachable = (returnVal==0);
            return reachable;
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return false;
    }


    // Fonction devant remplir le recycler ...
    public static void convert_tab (){


      /*
         Code destiné à alimenter le recycler view en ville, latitude et longitude pour l'utilisateur
        int taille_content_recycler = 0;
        tab_name = new String[taille_content_recycler];
        tab_lat = new String[taille_content_recycler];
        tab_lng = new String[taille_content_recycler];


        tab_name[taille_content_recycler] = getString()+taille_content_recycler;
        tab_lat[taille_content_recycler] = getLat()+taille_content_recycler;
        tab_lng[taille_content_recycler] = getLng()+taille_content_recycler;
        taille_content_recycler++;
       */

    }
}



